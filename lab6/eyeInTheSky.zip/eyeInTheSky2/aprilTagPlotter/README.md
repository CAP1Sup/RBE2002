# AprilTag Plotter

To run the tag plotter:

1. Navigate to the directory of the project (`aprilTagPlotter/`)

2. Install the required libraries:
   `pip install -r requirements.txt`

3. Run the tag plotter:
   `python plotTags.py`
